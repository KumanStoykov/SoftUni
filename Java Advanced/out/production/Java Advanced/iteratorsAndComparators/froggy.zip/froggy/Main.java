package iteratorsAndComparators.froggy;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Integer[] input = Arrays.stream(scanner.nextLine().split(", "))
                .map(Integer::parseInt).toArray(Integer[]::new);

        Lake lake = new Lake(input);

        System.out.println(String.join(", ", lake.getLake().stream().map(String::valueOf).toArray(String[]::new)));

        scanner.nextLine();
    }
}
